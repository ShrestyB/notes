export const colours = {
    Default: "rgb(32, 33, 36)",
    Red: "rgb(134, 47, 39, 0.5)",
    Orange: "rgb(172, 120, 25, 0.5)",
    Yellow: "rgb(190, 177, 29, 0.5)",
    Green: "rgb(88, 141, 28, 0.5)",
    Teal: "rgb(25, 117, 96, 0.5)",
    Blue: "rgb(32, 127, 148, 0.5)",
    Purple: "rgb(97, 33, 150, 0.5)",
    Pink: "rgb(141, 39, 95, 0.5)",
    Brown: "rgb(110, 55, 17, 0.5)",
    Grey: "rgb(98, 99, 99, 0.5)",
};
