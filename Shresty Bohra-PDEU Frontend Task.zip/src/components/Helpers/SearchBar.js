import React, { useState } from "react";

function Search() {
  const [notes, setNotes] = useState([  ]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredNotes, setFilteredNotes] = useState(notes);

  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);
    const filtered = notes.filter(note => note.toLowerCase().includes(query));
    setFilteredNotes(filtered);
  };

  return (
    <div>
      <input 
        type="text" 
        placeholder="Search notes." 
        value={searchQuery} 
        onChange={handleSearch} 
      />
      <div>
        {filteredNotes.map((note, index) => (
          <div key={index}>{note}</div>
        ))}
      </div>
    </div>
  );
}

export default Search;
